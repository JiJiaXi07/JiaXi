package com.xiaoshu.dao;

import com.xiaoshu.base.dao.BaseMapper;
import com.xiaoshu.entity.Menu;

public interface MenuMapper extends BaseMapper<Menu> {
}